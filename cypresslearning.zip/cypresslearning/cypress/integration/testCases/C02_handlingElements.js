describe('Check the page navigation',()=>{
    it('Verify Element visibility and attribute values',()=>{
    cy.visit('http://way2automation.com/way2auto_jquery/index.php')
    cy.url().should('include','.com')
    //cy.get('#load_box > #load_form > :nth-child(5) > input').should('be.visible').type('Joana')
    cy.get('#load_box > #load_form > :nth-child(5) > input').should('be.visible').invoke('attr','name').should('contains','name')

   
    })
    
    it('Verify Perent ,Child and Within Elements ',()=>{
        cy.visit('http://way2automation.com/way2auto_jquery/index.php')
        cy.url().should('include','.com')
        cy.get('#load_box').find('input').invoke('attr','type').should('not.have','hidden').its('length').then((elelength)=>{
            cy.log(elelength)
        })
        
        cy.get('#load_box > form > fieldset').children('input').its('length').then((elelength)=>{
            cy.log(elelength)
        })

        //find whithin that form / section /block 
        cy.get("#load_box > form > fieldset").within((selection)=>{
            cy.get('input').its('length').should('eq',6)
            cy.get('input').first().type('Way2Automation')
            cy.get("input[name='phone']").type('3029384')
            cy.wait(2000)
            cy.get('input').last().type('JOana')

        })

       
        })
        
        
    
    
    })
    