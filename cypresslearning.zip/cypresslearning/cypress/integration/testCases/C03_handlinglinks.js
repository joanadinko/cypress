describe('Handling links',()=>{
    it.only('Check links',()=>{
    cy.visit('https://www.wikipedia.org/')
    cy.get('a').contains('Commons').click()
    cy.get('.mainpage-welcome-sitename').should('contain.text','Commons')
    cy.get('a').its('length').then((elelength)=>{
        cy.log(elelength)
    })
    })
    
    
    
    })
    