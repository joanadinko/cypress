describe('Handling dropdowns',()=>{
    it('Select from dropdown',()=>{
    cy.visit('https://www.wikipedia.org/')
    cy.get("#searchLanguage").select('Eesti').should('have.value','et')

    
    
    
    })
})