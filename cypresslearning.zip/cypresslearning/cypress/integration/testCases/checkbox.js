describe('Handling checkbox',()=>{
    it('Select from checkbox',()=>{
    cy.visit('http://www.tizag.com/htmlT/htmlcheckboxes.php')
    //cy.get("input[type='checkbox']").check().should('be.checked')
    //cy.wait(2000)
    //cy.get("input[type='checkbox']").uncheck()
    cy.get("input[type='checkbox']").check(['football','baseball'])
    
    
    
    })
})