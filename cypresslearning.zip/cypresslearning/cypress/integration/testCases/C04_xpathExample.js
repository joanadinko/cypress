describe('Xpath example',()=>{
    it('Locating element by xpath',()=>{
    cy.visit('http://way2automation.com/way2auto_jquery/index.php')
   
    cy.xpath('/html/body/div[4]/div/div/div/div/div/form/fieldset[1]/input').type('Joana')
    cy.title().should('contains','Welcome')
    
   cy.fixture('example').then((data)=>{
    cy.log(data.name)
   })
    
    
    
    })
})