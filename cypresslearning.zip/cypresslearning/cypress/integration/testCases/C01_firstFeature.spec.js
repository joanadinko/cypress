describe('Check the page navigation',()=>{
it('Verify Page title',()=>{
cy.visit('http://way2automation.com/way2auto_jquery/index.php')
cy.url().should('include','.com')
cy.get('#load_box > #load_form > :nth-child(5) > input').type('Joana')
cy.title().should('contains','Welcome')

cy.get("#load_form > fieldset:nth-child(5) > label").eq(0).then((label)=>{
    cy.log(label.text());
    })
})



})
