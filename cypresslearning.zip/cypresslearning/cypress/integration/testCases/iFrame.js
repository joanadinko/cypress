describe('Handling iFrane',()=>{
    it('iFrame',()=>{
    cy.visit('https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_submit_get')

    cy.get('body > button').click()
    
    
    })
})